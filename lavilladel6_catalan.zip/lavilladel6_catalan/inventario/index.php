<?php
    //Este archivo vacio sirve para que no se pueda entrar en el directorio y ver las imagenes (para dar mas "misterio").
    //Puede borrarse si se prefiere consentir el acceso.
?>
